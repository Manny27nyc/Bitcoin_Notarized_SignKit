python3 ~/recover_keystore_password.py
