## Licensing Enforcement Notice — ENF-20250626-02

**To:** Multibit Legacy Project  
**Project:** [multibit](https://github.com/Multibit-Legacy/multibit)  
**Reuse Type:** Wallet Interface & Chain Parser  
**License Conflict:** Unattributed Bitcoin Fork  
**Estimated Licensing Fee Due:** $1,250,000 USD

As the author of the original Bitcoin protocol, I assert that Multibit has reused structural and functional aspects of my software without proper credit or license.

Remediation includes public attribution, licensing negotiation, and retroactive compliance.

Contact: Fordamboy1@gmail.com | GPG: B4EC 7343 AB0D BF24  
