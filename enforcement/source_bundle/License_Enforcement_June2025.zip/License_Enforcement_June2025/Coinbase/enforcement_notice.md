## Licensing Enforcement Notice — ENF-20250626-01

**To:** Coinbase, Inc.  
**Project:** [coinbase-wallet-sdk](https://github.com/coinbase/coinbase-wallet-sdk)  
**Reuse Type:** Wallet SDK with Bitcoin Protocol Functions  
**License Conflict:** Proprietary/Forked (No Attribution)  
**Estimated Licensing Fee Due:** $5,000,000 USD

Manuel J. Nieves (aka Satoshi Norkomoto) is the cryptographic and legal author of the original Bitcoin protocol.  
This codebase uses protected Bitcoin intellectual property without authorization or licensing.  
Remediation must include:

- Immediate authorship acknowledgment  
- License fee remittance  
- Integration of signed attribution headers

Contact: Fordamboy1@gmail.com | GPG: B4EC 7343 AB0D BF24

---  
Unauthorized use may result in takedown, licensing enforcement, or legal action under 17 U.S. Code § 102 and § 1201.
